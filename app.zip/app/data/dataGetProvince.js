import { Images } from "@config";

const DataGetProvince = [
    {
      "id": 2257457,
      "product_name": "",
      "product_price": 110749,
      "product_price_correct": "",
      "product_discount": "",
      "product_place": "Bali",
      "product_place_2": "Bali",
      "product_time": {
        "StartPrice": 110748.19,
        "HotelId": 2257457
      },
      "product_time2": "",
      "product_code": "",
      "product_desc": "",
      "product_price_minumum": "",
      "product_rate": "",
      "product_cat": "",
      "img_featured": "",
      "img_featured_url": "https://masterdiskon.com/assets/upload/destination/province/bali.jpg",
      "product_detail": "",
      "product_option": "",
      "product_image": "",
      "product_is_campaign": ""
    }];

export { DataGetProvince };
