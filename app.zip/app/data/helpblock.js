const HelpBlockData = {
    title: "Need Us Help ?",
    description: "we would be happy to help you",
    phone: "9-840-298-125 93",
    email: "contact@support.com"
};

export { HelpBlockData };
