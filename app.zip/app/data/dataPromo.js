import { Images } from "@config";

const DataPromo =  [
  {
      "name": "MDPL - Voucher Diskon 50% Tiket Pesawat ke Denpasar",
      "slug": "mdpl---voucher-diskon-50--tiket-pesawat-ke-denpasar",
      "image": "https://cdn.masterdiskon.com/masterdiskon/promotion/promo/2021/banner_mdpl-02-01_(1)-min.jpg",
      "valid_end": "16 Okt 2022"
  }
];

export { DataPromo };
