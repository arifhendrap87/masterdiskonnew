import { Images } from "@config";

const DataMasterDiskon = [
    {
        baseUrl: "https://jsx.masterdiskon.com/",
        //baseUrl: "https://sandbox.masterdiskon.com/",
        apiBaseUrl: "https://api.masterdiskon.com/v1/",
        //apiBaseUrl:"https://api.masterdiskon.com/v1/",
        username: "digidawdigidaw",
        password: "123456",
        dir: "front/api_new/common/config",
        pathCheckVersion: "front/api_new/common/versionapp",
        versionInPlayStore: 187,
        versionInAppStore: 187,
        versionInPlayStoreName: 'V.1.8.7',
        versionInAppStoreName: 'V.1.8.7',
        typeApp: 'b2c',
        defPassword: '567d61b86a88dccde8970f4092d6cddd158dc6a5',
        status: "production",
        //status: "sandbox",
    },

];

export { DataMasterDiskon };
