import { Images } from "@config";

const BookingHistoryData = [
    {
        id: "1",
        name: "Proxeloca Hotel",
        checkIn: "04 Jun 08",
        checkOut: "07 Jun 08",
        total: "2 Days 1 Night",
        price: "$399,99"
    },
    {
        id: "2",
        name: "Proxeloca Hotel",
        checkIn: "04 Jun 08",
        checkOut: "07 Jun 08",
        total: "2 Days 1 Night",
        price: "$399,99"
    },
    {
        id: "3",
        name: "Proxeloca Hotel",
        checkIn: "04 Jun 08",
        checkOut: "07 Jun 08",
        total: "2 Days 1 Night",
        price: "$399,99"
    },
    {
        id: "4",
        name: "Proxeloca Hotel",
        checkIn: "04 Jun 08",
        checkOut: "07 Jun 08",
        total: "2 Days 1 Night",
        price: "$399,99"
    }
];

export { BookingHistoryData };
