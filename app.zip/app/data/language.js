const LanguageData = [
    {
        id: "1",
        language: "English",
        checked: true
    },
    { id: "2", language: "Vietnames" },
    { id: "3", language: "Japanes" },
    { id: "4", language: "Korean" }
];

export { LanguageData };
