import { Images } from "@config";

const DataNotif = [
    {
        "id_notification": "2670",
        "tautan": "https://masterdiskon.com/front/user/purchase/detail/4277",
        "title": "Pesanan Baru telah dibuat",
        "content": "Pesanan dibuat dengan kode MD2009150024",
        "date_added": "2020-09-15 16:16:05",
        "id_user": "258",
        "seen": "0"
    },
];

export { DataNotif };
