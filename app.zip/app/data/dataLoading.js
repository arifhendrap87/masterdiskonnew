import { Images } from "@config";

const DataLoading = [
    {
        site: "https://masterdiskon.co.id/",
    },
    {
        site: "https://masterdiskon.co.id/",
    },
    
   
];

export { DataLoading };
