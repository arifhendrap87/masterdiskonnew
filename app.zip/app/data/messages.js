import { Images } from "@config";

const MessagesData = [
    {
        id: "0",
        user: "Sankhadeep",
        message: "Its time to build a difference ...",
        image: Images.avata1,
        date: "Dec 11, 2018"
    },
    {
        id: "1",
        user: "Sankhadeep",
        message: "Its time to build a difference ...",
        image: Images.avata2,
        date: "Dec 11, 2018"
    },
    {
        id: "2",
        user: "Sankhadeep",
        message: "Its time to build a difference ...",
        image: Images.avata3,
        date: "Dec 11, 2018"
    },
    {
        id: "3",
        user: "Sankhadeep",
        message: "Its time to build a difference ...",
        image: Images.avata4,
        date: "Dec 11, 2018"
    },
    {
        id: "4",
        user: "Sankhadeep",
        message: "Its time to build a difference ...",
        image: Images.profile1,
        date: "Dec 11, 2018"
    },
    {
        id: "5",
        user: "Sankhadeep",
        message: "Its time to build a difference ...",
        image: Images.profile3,
        date: "Dec 11, 2018"
    }
];

export { MessagesData };
