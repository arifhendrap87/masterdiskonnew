/**
 * Basic Setting Variables Define
 */
export const BaseSetting = {
    name: "masterdiskon",
    displayName: "Masterdiskon",
    appVersion: "1.0.4"
};
